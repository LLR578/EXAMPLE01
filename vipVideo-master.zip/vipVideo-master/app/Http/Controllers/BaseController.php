<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\1\13 0013
 * Time: 23:53
 */

namespace App\Http\Controllers;
class BaseController extends Controller{

}