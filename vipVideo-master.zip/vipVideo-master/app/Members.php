<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018\1\13 0013
 * Time: 17:26
 */
namespace App;

use Illuminate\Database\Eloquent\Model;

class Members extends Model{
    protected $table="Members";

}