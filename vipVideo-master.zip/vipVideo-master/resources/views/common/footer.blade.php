<div class="mdui-container" style="margin-top:60px;">
    <div class="mdui-row" style="margin-top: 50px;">
        <div class="mdui-col-xs-1 mdui-col-sm-3 mdui-col-md-2 mdui-col-lg-2"></div>
        <div class="mdui-col-xs-10  mdui-col-sm-6 mdui-col-md-6 mdui-col-lg-5">
            <div class="mdui-text-center">
                <p>2018©.<a href="https://vip.o11o.cc" class="mdui-text-color-pink">嗖嗖</a></p>
                <a href="feedback" class="mdui-text-color-pink">意见反馈</a> |

                <a href="about" class="mdui-text-color-pink">关于本站</a>
            </div>
        </div>
    </div>
</div>